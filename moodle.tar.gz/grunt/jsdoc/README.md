# Moodle JavaScript Documentation

```
                                 .-..-.
   _____                         | || |
  /____/-.---_  .---.  .---.  .-.| || | .---.
  | |  _   _  |/  _  \/  _  \/  _  || |/  __ \
  * | | | | | || |_| || |_| || |_| || || |___/
    |_| |_| |_|\_____/\_____/\_____||_|\_____)

Moodle - the world's open source learning platform

```

## About
This generated documentation includes API documentation for JavaScript written in the AMD and ES2015 module formats within Moodle.

## Related information
See [https://moodledev.io](https://moodledev.io) for other related Developer Documentation.
