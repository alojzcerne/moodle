# core_admin (subsystem) Upgrade notes

## 4.5dev+

### Added

- Add availability_management_table is a table which extends from plugin_management_table. Create the availability_management_table can reusable the toggle button for enabled column.

  For more information see [MDL-81533](https://tracker.moodle.org/browse/MDL-81533)
