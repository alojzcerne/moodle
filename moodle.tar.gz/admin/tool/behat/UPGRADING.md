# tool_behat Upgrade notes

## 4.5dev+

### Added

- Behat tests are now checking for deprecated icons. This check can be disabled by using the --no-icon-deprecations option in the behat CLI.

  For more information see [MDL-82212](https://tracker.moodle.org/browse/MDL-82212)

